import React from 'react';
export default function ExamStatistics({items=[]}){return <div className="exam-stat-grid">{items.map(x=><div className="exam-stat" key={x.label}><span>{x.label}</span><strong>{x.value}</strong></div>)}</div>}
