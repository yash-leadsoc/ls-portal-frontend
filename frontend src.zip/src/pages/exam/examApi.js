const BASE=(import.meta.env.VITE_API_URL||'http://localhost:5000/api');
const getAttemptToken=()=>sessionStorage.getItem('ls_exam_attempt_token');
async function request(path,{method='GET',body,attempt=false}={}){
 const headers={'Content-Type':'application/json'};
 if(attempt&&getAttemptToken())headers.Authorization=`Bearer ${getAttemptToken()}`;
 else {const t=localStorage.getItem('ls_token');if(t)headers.Authorization=`Bearer ${t}`;}
 const res=await fetch(`${BASE}${path}`,{method,headers,body:body?JSON.stringify(body):undefined});
 const data=await res.json().catch(()=>({}));
 if(!res.ok)throw new Error(data.message||'Request failed');return data;
}
export const examApi={
 list:()=>request('/exam/public/exams'),
 exam:id=>request(`/exam/public/exams/${id}`),
 register:body=>request('/exam/public/register',{method:'POST',body}),
 instructions:id=>request(`/exam/attempts/${id}/instructions`,{attempt:true}),
 start:id=>request(`/exam/attempts/${id}/start`,{method:'POST',body:{},attempt:true}),
 paper:id=>request(`/exam/attempts/${id}/paper`,{attempt:true}),
 save:(id,body)=>request(`/exam/attempts/${id}/answers`,{method:'PUT',body,attempt:true}),
 status:id=>request(`/exam/attempts/${id}/status`,{attempt:true}),
 submit:id=>request(`/exam/attempts/${id}/submit`,{method:'POST',body:{},attempt:true}),
 admin:(path,opts={})=>request(`/exam/${path}`,opts)
};
