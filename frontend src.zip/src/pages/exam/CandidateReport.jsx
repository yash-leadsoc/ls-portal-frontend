import React,{useEffect,useState} from 'react';
import {useParams} from 'react-router-dom';
import {adminRequest} from './adminApi';
import './exam.css';
export default function CandidateReport(){
  const params=useParams();const [data,setData]=useState([]),[error,setError]=useState('');
  useEffect(()=>{let p='../results';if(params.examId)p+='/'+params.examId+'/sets';if(params.setId)p='/admin/sets/'+params.setId+'/questions';if(params.attemptId)p='/results/'+params.attemptId;
    adminRequest(p).then(setData).catch(e=>setError(e.message));
  },[params.examId,params.setId,params.attemptId]);
  return <div className="exam-admin-content"><h1>Candidate Examination Report</h1>{error&&<p className="exam-error">{error}</p>}{Array.isArray(data)?<pre className="exam-json">{JSON.stringify(data,null,2)}</pre>:<pre className="exam-json">{JSON.stringify(data,null,2)}</pre>}</div>;
}
