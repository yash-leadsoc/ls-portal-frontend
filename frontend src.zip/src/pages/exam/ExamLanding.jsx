import React,{useEffect,useState} from 'react';
import {useNavigate} from 'react-router-dom';
import {examApi} from './examApi';
import './exam.css';
export default function ExamLanding(){
 const [exams,setExams]=useState([]),[error,setError]=useState('');const nav=useNavigate();
 useEffect(()=>{examApi.list().then(setExams).catch(e=>setError(e.message));},[]);
 return <main className="exam-shell"><header className="exam-brand">LEADSOC <span>EXAM PORTAL</span></header><section className="exam-hero"><div className="exam-kicker">LEARNING • ASSESSMENT • GROWTH</div><h1>Welcome to LeadSoc Exam Portal</h1><p>Test your knowledge, demonstrate your skills, and take the next step in your learning journey.</p></section><section className="exam-panel"><h2>Available examinations</h2>{error&&<p className="exam-error">{error}</p>}{!exams.length&&!error&&<p>No examinations are currently available.</p>}{exams.map(e=><article className="exam-item" key={e._id}><div><h3>{e.name}</h3><p>{e.description}</p><small>{e.durationMinutes} minutes · {e.maximumMarks} marks</small></div><button onClick={()=>nav(`/exam/register/${e._id}`)}>Start Exam</button></article>)}</section><section className="exam-panel"><h2>Examination guidelines</h2><ul><li>Keep a stable internet connection throughout the examination.</li><li>Read each question carefully before answering.</li><li>Your answers are saved automatically when connected.</li><li>Submit before the countdown reaches zero.</li><li>Do not refresh or close the examination window unnecessarily.</li></ul><p>For assistance, contact your LeadSoc examination coordinator.</p></section></main>;
}
